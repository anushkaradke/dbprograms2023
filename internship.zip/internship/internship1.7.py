#Write a program to accept ram and rom, display list of mobiles of the ram-rom storage space combination

import pymysql
from tabulate import tabulate

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
rm=int(input("Enter RAM(eg. 4,6): "))
ro=int(input("Enter ROM(eg. 128): "))
curs.execute("select * from MOBILES where ram=%d and rom=%d"%(rm,ro))
d=curs.fetchall()
if d:
    head = ["prodid","modelname","company","connectivity(4G/5G)","ram","rom","color","screen","battery","processor","price","rating","purpose"]
    print(tabulate(d,headers=head,tablefmt='grid'))
else:
    print("No such record found")

conn.close()
