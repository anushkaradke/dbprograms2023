#Write a program to display group by information - brand, total models under the company, average price and average rating.

import pymysql
from tabulate import tabulate
conn=pymysql.connect(host="bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com",user= "uviowoiza5khafcu" ,password="pARBUgbOexuKVnv2IscK" ,database= "bdhyveil1zk4oyoay7hn")
curs=conn.cursor()
curs.execute("select comapany,count(modelname),avg(price),avg(rating) from MOBILES group by comapany")
d=curs.fetchall()
head = ["company","Total models","price","rating"]
print(tabulate(d,headers=head,tablefmt='grid'))
conn.close()
