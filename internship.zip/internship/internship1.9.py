#Add new column "purpose varchar(50)" to the mobiles table using alter query

import pymysql

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
try:
    curs.execute("alter table MOBILES add purpose varchar(50)")
    d=curs.fetchall()
    print(d)
except:
    print("Column already exist")
curs.close()
