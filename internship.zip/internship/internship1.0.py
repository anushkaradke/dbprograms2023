#Create a table "MOBILES" with prodid as primary key and other fields like modelname, company, connectivity(4G/5G), ram, rom, color, screen, battery, processor, price, rating (4.3 out of 5)
import pymysql

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
curs.execute('create table MOBILES(prodid integer primary key,modelname varchar(50),comapany varchar(50),connectivity varchar(10) check (connectivity in ("2G","3G","4G","5G")),ram varchar(10),rom varchar(10),color varchar(30),screen float,battery integer,processor varchar(30),price float,rating float check (rating<=5))')
print("Table created")
