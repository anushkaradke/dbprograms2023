#Write a program to accept prodid, display the mobile data and ask "Do you want to delete?" if "yes" delete the mobile from the table

import pymysql
from tabulate import tabulate

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
i=int(input("Enter the product id you want to delete: "))
curs.execute("select * from MOBILES where prodid=%d"%i)
d=curs.fetchall()
if d:
    head = ["prodid","modelname","company","connectivity(4G/5G)","ram","rom","color","screen","battery","processor","price","rating","purpose"]
    print(tabulate(d,headers=head,tablefmt='grid'))
    inp=input("Do you really wish to delete this record(Yes/No): ")
    if inp.lower()=='yes':
        curs.execute("delete from MOBILES where prodid=%d"%i)
        print("Delete operation successfull")
    else:
        print("Delete operation avoided")
else:
    print("Product does not exist")
conn.commit()
conn.close()
    
