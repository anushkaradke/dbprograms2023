#Write a program to accept prodid & new price and update price in the mobile data in the table if found else display "mobile does not exist"


import pymysql
from tabulate import tabulate
conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
i = int(input("Enter product id : "))
curs.execute("select * from MOBILES where prodid=%d"%i)
d=curs.fetchall()
if d:
    head = ["prodid","modelname","company","connectivity(4G/5G)","ram","rom","color","screen","battery","processor","price","rating","purpose"]
    print(tabulate(d,headers=head,tablefmt='grid'))
    p =int(input("Enter the updated price : "))
    curs.execute("update MOBILES set price=%d where prodid=%d"%(p,i))
    curs.execute("select * from MOBILES where prodid=%d"%i)
    d=curs.fetchall()
    print("Updated Record: ")
    print(tabulate(d,headers=head,tablefmt='grid'))
else :
    print("Mobile does not exist")
conn.commit()
conn.close()
