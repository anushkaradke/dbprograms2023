#Write a program to accept modelname and purpose, update all mobiles of the model with the purpose ( gaming/office/social, etc.)


import pymysql

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
modelnm=input("Enter the model name: ")
curs.execute("select * from MOBILES where modelname='%s'"%modelnm)
d=curs.fetchall()
if d :
    purp=input("Enter the purpose: ")
    curs.execute("update MOBILES set purpose='%s' where modelname='%s'"%(purp,modelnm))
    print("Purpose column updated")
    conn.commit()
else :
    print("Record not found")
curs.close()
