#Write a program to accept company like "samsung" and display list of mobiles of that category in the ascending order of price

import pymysql
from tabulate import tabulate

conn=pymysql.connect(host='bdhyveil1zk4oyoay7hn-mysql.services.clever-cloud.com',user='uviowoiza5khafcu',password='pARBUgbOexuKVnv2IscK',database='bdhyveil1zk4oyoay7hn')
curs=conn.cursor()
comp=input("Enter the company you wish to search: ")
curs.execute("select * from MOBILES where comapany='%s' order by price"%comp)
d=curs.fetchall()
head = ["prodid","modelname","company","connectivity(4G/5G)","ram","rom","color","screen","battery","processor","price","rating","purpose"]
print(tabulate(d,headers=head,tablefmt='grid'))
conn.close()
